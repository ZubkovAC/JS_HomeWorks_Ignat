const initState = {

};

export const themeReducer = (state = initState, action: any): any => { // fix any
    switch (action.type) {
        case "": {
            return state;
        }
        default: return state;
    }
};

export const changeThemeC = (): any => {}; // fix any