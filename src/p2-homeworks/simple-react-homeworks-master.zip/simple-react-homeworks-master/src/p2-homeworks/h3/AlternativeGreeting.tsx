import React from "react";

function AlternativeGreeting() {
    return (
        <div>

        </div>
    );
}

export default AlternativeGreeting;
