import React from "react";

function Message() {
    return (
        <div>

        </div>
    );
}

export default Message;
